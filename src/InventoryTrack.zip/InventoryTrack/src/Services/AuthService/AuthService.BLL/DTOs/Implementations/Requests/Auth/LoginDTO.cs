﻿namespace AuthService.BLL.DTOs.Implementations.Requests.Auth;

public class LoginDTO
{
    public string Login { get; set; }
    public string Password { get; set; }
    
}