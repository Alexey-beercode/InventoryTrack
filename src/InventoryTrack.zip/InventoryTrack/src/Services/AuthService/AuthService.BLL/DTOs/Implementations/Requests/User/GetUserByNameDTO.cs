﻿namespace AuthService.BLL.DTOs.Implementations.Requests.User;

public class GetUserByNameDTO
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
}