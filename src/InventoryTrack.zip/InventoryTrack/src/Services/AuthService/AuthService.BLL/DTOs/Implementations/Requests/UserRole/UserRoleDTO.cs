namespace AuthService.BLL.DTOs.Implementations.Requests.UserRole;

public class UserRoleDTO
{
    public Guid UserId { get; set; }
    public Guid RoleId { get; set; }
}