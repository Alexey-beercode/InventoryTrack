namespace AuthService.BLL.DTOs.Implementations.Responses.Role;

public class RoleDTO
{
    public Guid Id { get; set; }
    public string Name { get; set; }
}