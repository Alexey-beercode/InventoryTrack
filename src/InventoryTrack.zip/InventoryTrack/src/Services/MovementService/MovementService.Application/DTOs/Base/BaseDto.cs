﻿namespace MovementService.Application.DTOs.Base;

public class BaseDto
{
    public Guid Id { get; set; }
}