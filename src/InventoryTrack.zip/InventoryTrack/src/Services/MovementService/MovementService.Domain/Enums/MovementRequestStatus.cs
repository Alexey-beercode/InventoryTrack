﻿namespace MovementService.Domain.Enums;

public enum MovementRequestStatus
{
    Processing,
    Rejected, 
    Completed
}