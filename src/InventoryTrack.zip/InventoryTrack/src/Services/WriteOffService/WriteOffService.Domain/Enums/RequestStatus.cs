﻿namespace WriteOffService.Domain.Enums;

public enum RequestStatus
{
    None,
    Requested,
    Created,
    Rejected
}