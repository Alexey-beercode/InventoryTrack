﻿namespace WriteOffService.Application.DTOs.Response.RequestStatus;

public class RequestStatusResponseDto
{
    public Domain.Enums.RequestStatus Value { get; set; }
    public string Name { get; set; }
}