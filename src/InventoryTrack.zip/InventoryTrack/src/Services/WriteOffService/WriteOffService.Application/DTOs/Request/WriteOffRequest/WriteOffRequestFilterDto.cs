﻿using WriteOffService.Domain.Enums;

namespace WriteOffService.Application.DTOs.Request.WriteOffRequest;

public class WriteOffRequestFilterDto
{
    public Guid ItemId { get; set; }
    public Guid WarehouseId { get; set; }
    public long Quantity { get; set; }
    public Guid ReasonId { get; set; }
    public RequestStatus Status { get; set; }
    public DateTime RequestDate { get; set; }
    public Guid? ApprovedByUserId { get; set; }
    public int PageSize { get; set; }
    public int PageNumber { get; set; }
}