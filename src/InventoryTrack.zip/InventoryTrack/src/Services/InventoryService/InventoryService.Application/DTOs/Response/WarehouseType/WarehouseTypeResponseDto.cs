﻿namespace InventoryService.Application.DTOs.Response.WarehouseType;

public class WarehouseTypeResponseDto
{
    public Domain.Enums.WarehouseType Value { get; set; }
    public string Name { get; set; }
}