﻿using InventoryService.Domain.Entities;

namespace InventoryService.Domain.Interfaces.Repositories;

public interface IDocumentRepository:IBaseRepository<Document>
{
    
}