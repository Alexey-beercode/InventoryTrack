﻿namespace InventoryService.Domain.Interfaces.Entities;

public interface IHasId
{
    Guid Id { get; set; }
}
