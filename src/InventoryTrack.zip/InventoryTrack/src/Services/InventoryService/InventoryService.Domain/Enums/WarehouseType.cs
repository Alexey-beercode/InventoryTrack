﻿namespace InventoryService.Domain.Enums;

public enum WarehouseType
{
    Production,
    Internal
}