﻿namespace InventoryService.Domain.Enums;

public enum InventoryItemStatus
{
    Requested,
    Created,
    Rejected
}