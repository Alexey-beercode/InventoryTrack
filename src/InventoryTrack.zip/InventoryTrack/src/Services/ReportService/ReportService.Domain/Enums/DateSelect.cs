﻿namespace ReportService.Domain.Enums;

public enum DateSelect
{
    Month,
    Week,
    Day,
    Year
}