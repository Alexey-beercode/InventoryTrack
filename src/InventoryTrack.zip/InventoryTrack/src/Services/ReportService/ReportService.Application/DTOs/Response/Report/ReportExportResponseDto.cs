﻿namespace ReportService.Application.DTOs.Response.Report;

public class ReportExportResponseDto
{
    public byte[] Content { get; set; }
    public string Name { get; set; }
}